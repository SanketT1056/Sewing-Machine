#ifndef CONFIG_H
#define CONFIG_H

#include "Arduino.h"

extern unsigned int lower;              // Variable to store the lowest sensor value
extern unsigned long pushBackCount;     // Counter for the number of pushback events
extern bool pushBackFlag;               // Flag to ensure pushback is counted only once per event
extern unsigned int cutThreshold;       // Threshold to detect if the machine is in pushback or idle
extern int productionThreshold;         // Threshold to detect if the machine is in production
extern bool productionStarted;          // Flag to track if production has started

extern unsigned long buttonPressTime;  // Variable to track when the button was first pressed
extern bool buttonPressed;             // Flag to check if the button is currently pressed

extern const char stichCountPin;  // Signal pin connected to D2
extern volatile int stichCount;  // Counter for magnetic pulses

extern unsigned long totalProductionTime;  // Total production time in seconds
extern unsigned long timeInMinutes;        // Variable to hold the current time in minutes
extern unsigned long storedTimeInMinutes;  // Variable to hold the stored time in minutes from EEPROM

#endif  // End the #ifndef block properly
