#include "Config.h"

//***************Variables For Production Time And Production Count***************//
unsigned long pushBackCount = 0;         // Counter for the number of pushback events
bool pushBackFlag = true;               // Flag to ensure pushback is counted only once per event
// unsigned int cutThreshold = 400;        // Threshold to detect if the machine is in pushback or idle
unsigned int cutThreshold = 310;        // Threshold to detect if the machine is in pushback or idle
int productionThreshold = 420;          // Threshold to detect if the machine is in production
bool productionStarted = false;         // Flag to track if production has started

//float timeInMinutes = 0.0;

const char stichCountPin = 2;           // Signal pin connected to D2
volatile int stichCount = 0;  // Counter for magnetic pulses

unsigned long storedTimeInMinutes = 0;        // Variable to hold the stored time in minutes from EEPROM
unsigned long timeInMinutes = 0;
unsigned long totalProductionTime = 0;  // Total production time in seconds
